<?php 
$domisili = ["Jakarta","Bogor","Depok","Tanggerang","Bekasi"];

$program_studi = [
    "SI" => "Sistem Informasi",
    "TI" => "Teknik Informatika",
    "BD" => "Bisnis Digital",
];    
    

?>